from selenium import webdriver
from selenium.webdriver.common.by import By
import time
driver = webdriver.Chrome("chromedriver.exe")
#driver.get("https://hub.docker.com/search?q=&image_filter=store&page=1")
#driver.get("https://hub.docker.com/search?q=&image_filter=open_source&page=20")
#driver.get("https://quay.io/search?page=1")

driver.implicitly_wait(5) #隐式等待，后续find_element操作每隔半秒钟去浏览器查找一次，直到找到，最长等待时间5秒钟
#cookie button id="onetrust-reject-all-handler"
#cookie=driver.find_element(By.CLASS_NAME,"onetrust-close-btn-handler")
#cookie.click()


#收藏量.MuiTypography-body1.css-12r72vy    .css-60kwwm > strong
#stars=driver.find_elements(By.CSS_SELECTOR, ".css-60kwwm > strong")
#下载量.MuiTypography-root.MuiTypography-body1.css-12r72vy
#pulls=driver.find_elements(By.CSS_SELECTOR, ".MuiTypography-root.MuiTypography-body1.css-12r72vy")
#for star in stars:
#    print(star.text)
#for pull in pulls:
#    print(pull.text)

#drivers=driver.find_elements(By.CSS_SELECTOR, '[data-testid="product-title"]')
#for d in drivers:
#    print(d.text)
#下载量.MuiTypography-root.MuiTypography-body1.css-12r72vy
#pulls=driver.find_elements(By.CSS_SELECTOR, ".MuiTypography-root.MuiTypography-body1.css-12r72vy")
#for pull in pulls:
#    print(pull.text)
#updated=driver.find_elements(By.CSS_SELECTOR, ".jss16 + .MuiTypography-body1.css-60kwwm")
#for up in updated:
#    print(up.text)

#stars被挡住一部分不太方便爬取
#.styles-module__starCount___x3o5R > .MuiTypography-root.MuiTypography-body1.css-60kwwm > strong
#stars=driver.find_elements(By.CSS_SELECTOR, ".styles-module__starCount___x3o5R > .MuiTypography-root.MuiTypography-body1.css-60kwwm > strong")
#for star in stars:
#    print(star.text)
zoom_out= "document.body.style.zoom='0.8'"  #调节浏览器缩放大小





#========https://quay.io/search?page=1======================================================================================================
#drivers=driver.find_elements(By.CSS_SELECTOR, 'h4 > a')
#for d in drivers:
#    print(d.text)
#updated=driver.find_elements(By.CSS_SELECTOR, "[am-time-ago]")
#for up in updated:
#    print(up.text)
#stars=driver.find_elements(By.CSS_SELECTOR, "span.star-count-number")
#for star in stars:
#    print(star.text)













