from selenium import webdriver
from selenium.webdriver.common.by import By
import time
driver = webdriver.Chrome("chromedriver.exe")

driver.implicitly_wait(10) #隐式等待，后续find_element操作每隔半秒钟去浏览器查找一次，直到找到，最长等待时间5秒钟

mylist=[]
def official_name():
    for x in range(1, 9):
        driver.get(
                "https://hub.docker.com/search?image_filter=official&q=&page={}".format(x))
        #print("#第"+str(x)+"页")
        time.sleep(5)
        drivers = driver.find_elements(By.CSS_SELECTOR, '[data-testid="product-title"]')
        #drivers = driver.find_elements(By.CSS_SELECTOR, '.MuiTypography-root.MuiTypography-body1.css-1mod47s')
        for d in drivers:
        #    print(d.text)
            mylist.append(d.text)
        print(x)
        print(mylist)

    for j in mylist:
        driver.get("https://hub.docker.com/r/{}/tags".format(j))
        time.sleep(5)
        try:
            tag = driver.find_element(By.CSS_SELECTOR, '.styles-module__title_name___dNJgN '
                '.MuiTypography-root.MuiTypography-inherit.MuiLink-root.MuiLink-underlineAlways.css-1nqtld6')

            print(j + ":" + tag.text)
        except:
            print(j)

def official_update_time():
    for x in range(1, 9):
        driver.get(
                "https://hub.docker.com/search?image_filter=official&q=&page={}".format(x))
        #print("#第"+str(x)+"页")
        time.sleep(5)
        drivers = driver.find_elements(By.CSS_SELECTOR, '.MuiTypography-root.MuiTypography-body1.css-1mod47s')
        for d in drivers:
            print(d.text)

def official_pull():
    for x in range(1, 9):
        driver.get(
                "https://hub.docker.com/search?image_filter=official&q=&page={}".format(x))
        #print("#第"+str(x)+"页")
        time.sleep(5)
        drivers = driver.find_elements(By.CSS_SELECTOR, '.MuiTypography-root.MuiTypography-body1.css-12r72vy')
        for d in drivers:
            print(d.text)

def official_star():
    for x in range(1, 9):
        driver.get(
                "https://hub.docker.com/search?image_filter=official&q=&page={}".format(x))
        #print("#第"+str(x)+"页")
        time.sleep(5)
        drivers = driver.find_elements(By.CSS_SELECTOR, '.styles-module__starCount___x3o5R   .MuiTypography-root.MuiTypography-body1.css-60kwwm strong')
        for d in drivers:
            print(d.text)


def monero_name():
    # for x in range(1, 28):
    #     driver.get(
    #             "https://hub.docker.com/search?q=monero&page={}".format(x))
    #     #print("#第"+str(x)+"页")
    #     time.sleep(5)
    #     drivers = driver.find_elements(By.CSS_SELECTOR, '[data-testid="product-title"]')
    #     #drivers = driver.find_elements(By.CSS_SELECTOR, '.MuiTypography-root.MuiTypography-body1.css-1mod47s')
    #     for d in drivers:
    #     #    print(d.text)
    #         mylist.append(d.text)
    #     print(x)
    #     print(mylist)
    mylist=['zerosoul/monero-full-node', 'servethehome/monero', 'fflament/monero', 'bensteger/monero-node', 'ezminers/monero-wallet', 'heavenike/monero-dev', 'sonm/monero-amd', 'noonien/monero-stratum', 'jtowler/monero-ocean', 'abernalm/monero_cpu_minergate', 'coda4k/monero-miner', 'linn21/monero-cpuminer', 'killonexx/monero-pool', 'vekabhova/monero-kub', 'nake13/monero-miner', 'owahlen/monero-wallet-cli', 'easyhash/monerov', 'servethehome/monero_cpu_xmrpooldotnet_nproc', 'hebus/monero_noaes', 'brahim777/monero', 'cplilqw/monero-miner', 'kostola/monero-xmrig-miner', 'mehdiradhouani/monero-cpuminer', 'lzh7687/monerod', 'cirko/monero-docker', 'rohnin/monerod', 'calvintam236/monero-wallet-rpc', 'skyraptor/monerod', 'enucatl/monerod', 'tombeynon/monero-full-node', 'rangerhq/monerodockeraws', 'benwaddell/monerod', 'zyseu/monero_cpu_minergate', 'huycuong131094/monero', 'walkerlee/monero', 'lalanza808/monerod_exporter', 'iartem/monero-testnet', 'hitconey0f/monero', 'cryptogrampy/monero-lws', 'erzetdev/monero', 'seb1055/monero-miner', 'uschti/monero-miner', 'ljachym/monerod', 'hebus/monero', 'postables/monero-armv7', 'xnum/monero', 'mamuroti/monero_minergate', 'tuco86/monero-miner', 'tysat/monero', 'adrianomartins/monero-miner', 'bensteger/monero-pool', 'geekfil/monero', 'fascinatedcow/monero', 'jason20005/monerod', 'cryptobridge/monero', 'owahlen/monerod', 'valentinvieriu/monero', 'zealic/monero', 'vmatekole/monero', 'bensteger/monero-miner-arm', 'magnustiberius/monero', 'mixhq/monero', 'frapposelli/monerod', 'iartem/monero-sign', 'owahlen/monero-wallet-rpc', 'taoyou/monero', 'jinzhu/moneroclassic', 'r4ffy/monerovpn', 'sp4ke/monero', 'koce/monerod', 'frapposelli/monero-stratum', 'ogrant/monero-miner', 'm0thm/monero_mine', 'vekabhova/monero-kublite', 'onitsoft/monerod', 'hesperus/monerod', 'kary993/monerocoin', 'littleblackfish/monero', 'waltersouto/monerod', 'datty/monero', 'frapposelli/monero-xmr-stak', 'qtipeveryone/monerod', 'utxobr/monero-operator', 'wippy00/monero', 'valentinvieriu/monero-stratum', 'miningcontainers/xmrig', 'freakachoo/monero-xmr-stak', 'iartem/monero-dev', 'onitsoft/monero-wallet', 'patsissons/monero-wallet', 'm0thm/monero_mine_pi', 'ephz3nt/moneroclassic', 'hudocker/monero-daemon', 'anthony42d/monero-hyc', '4reallive/monerod', 'bclermont/monero', 'devfsp/moneropool-hashrate-logger', 'skinder/monero-test', 'reinaldocancino/monero', 'tat2bu/monero-cpuminer', 'bessonov/monero-miner', 'kuix/monero-miner', 'rbrtweiler/monero-cpu-miner', 'mpashkovskiy/monero-wallet', 'loganballard/monero-arm', 'ostlerdev/monero-full-node', 'devsamuelv/monero-miner', 'takato/monerofullnode', 'someguy123/monero', 'lnxd/moneronode', 'oigbash/monero-miner', 'issec2009/monero-wallet-rpc', 'chai2010/monero-docker', 'zcole/monero', 'stykers/monero', 'yashiroo/monerominer', 'vekabhova/monero-xansolo', 'samnco/monero_gpu', 'm0thm/monero_mine_nvidia', 'semyon2105/monerod', 'joshpurvis/monero', 'metal3d/xmrig', 'cryptoandcoffee/monero-pool', 'l1keen/monerod', 'usrcoin/monero', 'wshub/monero', 'vothanhkiet/monero', 'waterblock/monero-android_x64', 'ayayronstotle/monero_multiarch', 'lonangel/monerod-docker', 'ismaelu/monero-xmrig', 'pocoyo/monero', 'brodsky/monerod', 'discipleofhoid/monero_cpu_xmrpool', 'krism142/monero_base', 'waterblock/monero-android_x86', 'oddhome/monerod', 'yaweffa/monero', 'hudocker/monero-base', 'ankarenkoserj/monero_ubuntu', 'waterblock/monero-android', 'vekabhova/monero-xa', 'velvetvaldes/monero-daemon', 'tkeber/monero-exporter', 'kingdom998/monero', 'guybrush/monero-builder', 'ephz3nt/moneroclassic-wallet', 'magichuihui/monero', 'coinvest/monero', 'noah710/monero', 'trobim/monero', 'romanmc72/monero-miner', 'waterblock/monero-linux', 'devopz/monero', 'kingdom998/monero-base', 'postables/monero-armv8', 'milk4candy/monero-client', 'zz00cc/monero-docker-miner', 'milk4candy/monero-0.11.0.0', 'docker457076338/monero', 'qautomatron/xmrig', 'cniweb/xmrig', 'jalavosus/monerod', 'cannibal3004/monero-gui-xpra', 'thisischor/monero', 'milk4candy/monero-0.11.1.0', 'macruss/monero', 'null0pointer/monerod', 'epicmorg/monero', 'mynicehash/monero-miner', 'egeneralov/monero-classic', 'alebian/monero', 'neonstar/monerod', 'hansdr/monero', 'ganawa/monero', 'utxobr/monero-operator-0f25b68d038cd3967cd5a1bc4733cad6', 'alecov/monero', 'italianjack/monero-xmrig-mine', 'utxobr/monero-encrypted-p2p-f7ee08378917024fe0d9d7b1e927230a', 'fernandezjanmichael/monero', 'bfdnd/monero-full-node', 'flekmatik/monero', 'lchaia/xmrig-mo', 'leon153/monero_xmrig', 'beverts312/monero-miner', 'comminutus/monero', 'yrzr/monero', 'rimura/monero', 'marker689/monero', 'cryptoandcoffee/monero-blockchain', 'joaops95/monerominer', 'sethsimmons/simple-monerod', 'win33/minemonero', 'bombel415/monero', 'psvdevelop/monerod', 'bombel415/monero-wallet', 'rw102/monerod-node', 'deewhy/monero_miner', 'federkicco/monerominerdocker', 'pacificventuresltd/monero', 'skyraptor/monerod-pruned', 'sauromates/monero-ci', 'song22/monero', 'teehone/monero', 'drew6017/monero-java-docker', 'fascinatedcow/monerod', 'btw1217/monerod', 'vekabhova/monero-xan', 'sethsimmons/p2pool', 'yatima1460/monero', 'athulr7/monero', 'eliassosu/monero_miner', 'ryeguy/wolf9466-cpuminer-multi', 'cryptohash/xmrig-docker', 'sarangsohailhome/monerotest-amd64', 'milkliver/monero-miner', 'lalanza808/monero-lws', 'evinsoft/monerod', 'robotdna/monero-node', 'donafro/xmrig', 'thescobber/xmr-miner', 'romanmc72/monero-daemon', 'lalanza808/monerod', 'sarangsohailhome/monerotest', 'marcelcosta/monero', 'redrager/monero-dashboard', 'minounymous/monero-1822', 'jnitecki/monero', 'b4lddocker/xmrig', 'rcmelendez/xmrig', 'palobo/xmr-node-proxy', 'bitnn/alpine-monero-miner', 'brahim7/docker-minergate-climonero', 'martinplaner/xmrig', 'aloxaf/monero', 'phoenixsteel/monero', 'linuxbench/sth_monero_nvidia_gpu', 'mrtb/xmr-cpuminer-multi', 'rbeumer/monero-miner', 'nyancod3r/monero_cli', 'mikeramsey/monero-full-node', 'leen15/xmr-miner-cpu', 'darkcheyenne/monero-full-node', 'pmietlicki/xmrig-nvidia', 'exilesprx/xmrig', 'monerohustle/monerohustle', 'davidprocode/monero', 'mosaic0603/monero-node-md', 'goulchen/monero-full-node', 'imelnichenko/monero', 'issec2009/monero', 'f4bio/monero-full-node', 'khell/xmrig-docker', 'moneropro7650/mc', 'monero/win2016miner', 'monero/miner-win2016', 'moneroto/moneroto', 'moneromine69/monero-miner', 'cbarraford/cryptonoter-docker', 'normoes/xmrblocks', 'babim/xmrig-proxy', 'merxnet/xmrig-cpu', 'mcjon3z/xmrig', 'goulchen/monero-full-nodes', 'moonramp/monero', 'marcschweiger/moneropay', 'merxnet/xmr-stak-nvidia', 'monerominer2/cpuminer-multi', 'herrera/xmrig-cpu', 'elasticrock/monerod', 'merxnet/xmrig-nvidia', 'xdogex/monero_node_pruned', 'rootlogin/cpuminer', 'iluvmonero/xmrpool', 'aaronmboyd/xmrminer', 'merxnet/xmr-stak-cpu', 'flatbits/xmr', 'cornfeedhobo/bitmonero', 'sysrex/docker-monero', '1102836917/centos7_monl', 'kimostberg/xmrig-docker', 'uavresourcesdocker/uav-monero', 'mazhead/alpine_monerod', 'merxnet/xmrig-amd', 'tseabra/coin-hive', 'thelolagemann/xmrig-mo', 'bitwyre/crypto-monero', 'apocalypticuniverse/alpine-xmrig-armv7', 'merxnet/xmr-stak-amd', 'iofq/docker-xmrig', 'korius/node-nodemon', 'andyceo/xmr-stak-cpu', 'curlyxi/debian-xmr-stak', 'msouvik19/monero_cpu_minergate', 'mlgx/monerod', 'midhunramadas/minergate-cpu-xmr-fcn', 'andypost/xmrig', 'anecula/cpu-mining-on-docker-ubuntu', 'pajace/xmrig', 'buhathacit/xmrcpuminer', 'kenayagi/xmrig-proxy', 'vtorhonen/ez-docker-monero', 'linuxbench/sth_monero_cpu', 'andruby/minerd', 'bowwow/xmr-miner-autobuild', 'negov62438/mymonerolinux', 'costan/xmrig-mo-new', 'grinco/xmrig', 'jpacerqueira83/container_cryptominer', 'wentzien/xmrig', 'snex00/xpg', 'enemico/rocco', 'driftcrow/xmr-miner-cpu', 'mpaicil/cpuminer', 'iamballl/xmrig', 'busyboredom/acceptxmr', 'apocalypticuniverse/alpine-xmrig-x64', 'mineblocks/xmr-stak-cpu', 'negov62438/minerlinuxmonero', 'sliffelis/sshd-xmrminer', 'medall1st/cripting_m', 'andregasser/xmr-stak', 'ib4n3z/xmrig-alpine', 'hcmko/vast_nicehash_miner', 'devkube/mine-aeon', 'fallen90/web-miner-xmr', 'rifisourre/monerocentric-merchant-marketplace-idea-monero', 'taoyou/xmr-stak', 'syntheticore/monerod', 'nursecurtis/monerov', 'febro/monero-mine', 'raphaelareya/monerominer', 'ferdiwardiyan/monero', 'vdo1138/monero', 'froyobin/monero-wallet', 'shiftybee/monero', 'ciceromaurina/monero_cpu_minergate', 'zupfnesnaschtarp/monero-cpu-miner-for-mac', 'audriusbl/monero-node-rpc', 'snowlenconsto/monero-log-in-zcash-wallet-for-mac', 'jasonymy/xmr_u1604', 'benhall847/monero-full-node', 'krystalajackson/monerocasino', 'hirucalzi/monero_cpu_minergate', 'puntxr/xmrig', 'phatpham9/coinhive-nodejs-miner', 'jinzhu/xmc', 'mattvirus/xmrig-mo', 'csaber67/iox_monero_miner', 'korius/awesome-node-image', 'masszani/xmr-stak-miner', 'doublebyte/xmr-stak', 'ccarterc/miner', 'nektro/docker-monero', 'cryptogrampy/mymonero-web-js', 'elycin/monero-miner', 'ffteixx01/monero-miner', 'brahim7/moneromining', 'supermonero/monero', 'jguarecuco/monero', 'juliepadkins/monero_news', 'cirko/monero', 'maksimsavich/monero-full-node', 'wraithdf/monerod-docker', 'whatdoesthefoxsay/monero-ubuntu', 'l1keen/monero_wallet', 'robingreeve/monero', 'carlosmonero/monero_linux', 'yuritorres/monero-miner-docker', 'venstruprowland00/monerowallet', 'bitcoinreyes/monero-node', 'virpirmallat/monero-price-prediction', 'tsa31584/monerod', 'mariannasebe35/monerowallet', 'davidrrayner/monerofaucet', 'runramrom/monero', 'lifesbrain/monero-miner', 'lukrin/monero-node-forked', 'jam1/moneroocean', 'rustyshacklefurd/cryptids', 'cryptogrampy/hotshop', 'mryattle/xmrig', 'hiahatf/xmrblocks', 'marekobuchowicz/xmrig', 'frankzhong1992/xmrig-docker', 'harlok/archlinux-monero', 'cryptrent/xmrig', 'gagameson/xmrig', 'shangyaqi/xmr', 'owenbernsee/my-rig', 'korjavin/docker-monero-node', 'elisecoley/elisecoley', 'blockmintvvt/mining-pool', 'eyedeekay/xmr-wasm', 'goldmisptopre1985/download-monerodexe-file-mac', 'predatortr/xmr-cpu-miner', 'opwatoleab/desktop-mining-bitcoin-monero-ethereum-v-400-kenntess', 'amcguire2500/alpinexmr', 'mattvirus/xmr-node-proxy-mo', 'risubbule/desktop-mining-bitcoin-monero-ethereum-v-400', 'kdev0052/xmrig-alpine-optimized']

    for j in mylist:
        driver.get("https://hub.docker.com/r/{}/tags".format(j))
        time.sleep(5)
        try:
            tag = driver.find_element(By.CSS_SELECTOR, '.styles-module__title_name___dNJgN '
                '.MuiTypography-root.MuiTypography-inherit.MuiLink-root.MuiLink-underlineAlways.css-1nqtld6')

            print(j + ":" + tag.text)
        except:
            print(j)

def dblp_ASE_2023():
    driver.get(
            "https://dblp.org/db/conf/raid/raid2023.html")
    #print("#第"+str(x)+"页")
    time.sleep(5)
    drivers = driver.find_elements(By.CSS_SELECTOR, '.title')
    #drivers = driver.find_elements(By.CSS_SELECTOR, '.MuiTypography-root.MuiTypography-body1.css-1mod47s')
    i=0
    for d in drivers:
        print(str(i)+"  "+d.text)
        i=i+1

def dblp_topic():
    driver.get(
            "https://dblp.org/db/conf/uss/uss2023.html")
    #print("#第"+str(x)+"页")
    time.sleep(5)
    drivers = driver.find_elements(By.CSS_SELECTOR, '.h2 h2')
    #drivers = driver.find_elements(By.CSS_SELECTOR, '.MuiTypography-root.MuiTypography-body1.css-1mod47s')
    i=0
    for d in drivers:
        print(str(i)+"  "+d.text)
        i=i+1


def pull_images(imagename):
    for x in range(1, 101):
        driver.get(
                "https://hub.docker.com/search?q={}&page={}".format(imagename,x))
        #print("#第"+str(x)+"页")
        time.sleep(5)
        drivers = driver.find_elements(By.CSS_SELECTOR, '[data-testid="product-title"]')
        for d in drivers:
            print(d.text)



#dblp_topic()
#dblp_ASE_2023()
#'busybox','ubuntu','debian','python','redis','nginx','postgres''wordpress','tomcat','bash','httpd','mysql',
# 'mongo','rabbitmq','docker','openjdk','golang','centos','php','thrift'


# official_list=[
#     'memcached',
#     'node',
#     'traefik',
#     'mariadb',
#     'registry',
#     'consul',
#     'influxdb',
#     'nextcloud',
#     'sonarqube',
#     'ruby',
#     'haproxy',
#     'amazonlinux',
#     'elasticsearch',
#     'maven',
#     'tomcat',
#     'eclipse-mosquitto'
#     'sonarqube',
#     'ruby',
#     'telegraf',
#     'caddy',
#     'vault',
#     'adminer'
#    'ghost',
#    'kong',
#    'zookeeper',
#    'neo4j',
#    'perl',
#    'mongo-express',
#    'buildpack-deps',
#    'gradle',
#    'cassandra',
#    'nats',
#    'logstash'
#    'couchdb'
# ]

official_list=[
    'kibana',
    'percona',
    'drupal',
    'jenkins',
    'solr',
    'java',
    'composer',
    'chronograf'
]

for imagename in official_list:
    pull_images(imagename)
    print("===============================")
    print("===============================")


