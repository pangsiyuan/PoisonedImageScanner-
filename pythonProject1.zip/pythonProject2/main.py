
a=6
b=5
small=a if a<b else b
print(small)

nums = [1, 2, 3, 4, 5]
labels = ["odd" if num % 2 == 1 else "even" for num in nums]
print(labels)  # 输出：['odd', 'even', 'odd', 'even', 'odd']
